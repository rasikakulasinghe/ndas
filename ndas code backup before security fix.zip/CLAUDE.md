# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

<!-- OPENSPEC:START -->
# OpenSpec Instructions

These instructions are for AI assistants working in this project.

Always open `@/openspec/AGENTS.md` when the request:
- Mentions planning or proposals (words like proposal, spec, change, plan)
- Introduces new capabilities, breaking changes, architecture shifts, or big performance/security work
- Sounds ambiguous and you need the authoritative spec before coding

Use `@/openspec/AGENTS.md` to learn:
- How to create and apply change proposals
- Spec format and conventions
- Project structure and guidelines

Keep this managed block so 'openspec update' can refresh the instructions.

<!-- OPENSPEC:END -->

## Project Overview

**Neurodevelopmental Assessment System (NDAS)** - Django-based medical information system for managing patient records, video-based neurodevelopmental assessments, and standardized evaluation workflows in pediatric healthcare settings.

**Stack:** Django 4.2.16 + PostgreSQL/SQLite + AdminLTE 3.2 + Bootstrap 4.6 + HTMX + Video.js

**Apps:**
- `patients/` - Patient management, assessments, medical records (primary app at root URL)
- `video/` - Video file handling and processing
- `users/` - Authentication, profiles, subscriptions, activity tracking
- `reports/` - Report generation (PDF and Excel exports with data anonymization)

## Development Commands

```bash
# Environment (Windows)
venv\Scripts\activate
pip install -r requirements.txt

# Database
python manage.py makemigrations [app_name]
python manage.py migrate
python manage.py createsuperuser

# Run
python manage.py runserver

# Testing
python manage.py test                          # All tests
python manage.py test patients                 # App tests
python manage.py test users.tests.TestClassName  # Specific test

# OpenSpec
openspec list                                  # List active changes
openspec show [item]                           # View change/spec
openspec validate [change-id] --strict         # Validate change
openspec archive <change-id> --yes             # Archive deployed
```

## Architecture Patterns

### Model Development (MANDATORY)

All models MUST inherit from both base classes:

```python
from ndas.custom_codes.Custom_abstract_class import TimeStampedModel, UserTrackingMixin

class MyModel(TimeStampedModel, UserTrackingMixin):
    # Auto-provides: created_at, updated_at, added_by, last_edit_by
    # User tracking auto-populated by UserActivityMiddleware
    pass
```

**Custom Code Organization:**
- `ndas/custom_codes/Custom_abstract_class.py` - Base models
- `ndas/custom_codes/choice.py` - All TextChoices for dropdowns
- `ndas/custom_codes/validators.py` - Field validators
- `ndas/custom_codes/custom_methods.py` - Utilities (e.g., `getCountZeroIfNone()`, `calculate_age_string()`, `extract_video_metadata()`)
- `ndas/custom_codes/ndas_enums.py` - Enumerations (e.g., `PtStatus`)
- `ndas/custom_codes/delete_helpers.py` - Centralized entity deletion utilities (permission checks, business rules, redirects)

**Model Rules:**
1. Add choices to `choice.py` (use Django TextChoices)
2. Use validators from `validators.py`
3. Add `db_index=True` for searchable/filterable fields
4. Use date-based upload paths: `upload_to="path/%Y/%m/"`

### View Pattern

```python
from django.contrib.auth.decorators import login_required
from ndas.custom_codes.custom_methods import getCountZeroIfNone

@login_required(login_url="user-login")
def my_view(request):
    var_objects = MyModel.objects.all()
    count = getCountZeroIfNone(var_objects)
    return render(request, "myapp/template.html", {"var_objects": var_objects, "count": count})
```

### Form Pattern

```python
class MyForm(forms.ModelForm):
    class Meta:
        model = MyModel
        fields = ["field1", "field2"]
        widgets = {
            "text_field": forms.TextInput(attrs={"class": "form-control"}),
            "date_field": forms.DateInput(attrs={"class": "form-control", "type": "date"}),
        }
```

### Template Pattern (MANDATORY)

```django
{% extends 'src/base.html' %}  {# Authenticated pages #}
{% load static %}
{% block title %}Section - Action | Context{% endblock %}
{% block main_content %}
<div class="container-fluid">
  {% csrf_token %}
  <!-- Content -->
</div>
{% endblock %}
```

**Template Rules:**
- Extend `'src/base.html'` (authenticated) or `'src/basic_plane.html'` (public)
- Include `{% csrf_token %}` in container-fluid divs
- **DO NOT change CSS framework** - AdminLTE 3.2 + Bootstrap 4.6 + Font Awesome 6.4
- Naming: `manager.html` (lists), `add.html` (create), `edit.html` (update), `view.html` (detail)

### Security Architecture

**Middleware Stack (CRITICAL ORDER):**
1. SecurityMiddleware
2. WhiteNoiseMiddleware
3. CSPMiddleware
4. SessionMiddleware
5. CommonMiddleware
6. CsrfViewMiddleware
7. AuthenticationMiddleware
8. UserActivityMiddleware (custom - auto-tracks user changes)
9. MessageMiddleware
10. XFrameOptionsMiddleware
11. UserAgentMiddleware
12. SubscriptionCheckMiddleware (custom)

**Security Features:**
- Session timeout: 1 hour with browser-close expiry
- Rate limiting with django-ratelimit
- File upload validation (type, size, content)
- Medical data privacy (HIPAA awareness)

**File Upload Limits:**
- Videos: 2GB (mp4, mov, avi, mkv, webm)
- General: 100MB memory limit
- Profile pictures: 5MB

## Medical Domain

**Patient Identifiers:** BHT, NNC, PTC, PC, PIN, Disk No.

**Validation Ranges:**
- Birth weight: 300g - 8000g
- APGAR scores: 0-10
- Gestational age: 20-44 weeks + 0-6 days

**Assessment Types:** GPA, HINE, CDIC, Developmental

### Patient Model Field Reference (CRITICAL)

**Common Field Errors - Always verify field names:**

```python
# Identifiers
patient.bht              # NOT bht_number
patient.nnc_no           # NOT nnc_number
patient.ptc_no           # NOT ptc_number
patient.pc_no            # NOT pc_number
patient.pin              # NOT pin_number
patient.disk_no          # NOT disk_number

# Demographics
patient.baby_name        # NOT patient_name or name
patient.mother_name      # NOT mother
patient.gender           # ✓ correct
patient.dob_tob          # NOT date_of_birth or dob

# Birth Data
patient.pog_wks          # NOT gestational_age_weeks or pog_weeks
patient.pog_days         # NOT gestational_age_days
patient.mo_delivery      # NOT mode_of_delivery
patient.birth_weight     # NOT birth_weight_g or weight
patient.length           # ✓ correct
patient.hc               # NOT head_circumference

# APGAR Scores
patient.apgar_1          # NOT apgar_1_min or apgar1
patient.apgar_5          # NOT apgar_5_min or apgar5
patient.apgar_10         # NOT apgar_10_min or apgar10
```

## Key Development Rules

**Always:**
- Inherit models from `TimeStampedModel, UserTrackingMixin`
- Add choices to `ndas/custom_codes/choice.py`
- Use validators from `ndas/custom_codes/validators.py`
- Index searchable fields with `db_index=True`
- Extend base templates (`src/base.html` or `src/basic_plane.html`)
- Include CSRF tokens in forms
- Validate file uploads

**Never:**
- Add choices directly in models
- Skip field validation or indexing
- Change CSS framework or Bootstrap versions
- Bypass or reorder security middleware
- Store sensitive config in code (use `.env`)
- Use incorrect Patient model field names (verify above)

## Production Configuration

**Database:** SQLite (dev) / PostgreSQL (prod with connection pooling)
**Cache/Session:** Redis (prod) / LocMem (dev)
**Static Files:** WhiteNoise with compression
**External Dependencies:** FFmpeg, Redis, PostgreSQL, Celery (optional)

## Reports Module

**PDF Generation** (`reports/utils/pdf_generator.py`):
- `BasePDFGenerator` - Base class with styling, headers/footers, page configuration
- `PatientPDFGenerator` - Comprehensive patient reports
- `GMAssessmentPDFGenerator` - GM Assessment reports
- `HINEAssessmentPDFGenerator` - HINE Assessment reports
- `DAAssessmentPDFGenerator` - Developmental Assessment reports
- `CDICAssessmentPDFGenerator` - CDIC Record reports
- `GPAAssessmentPDFGenerator` - General Paediatric Assessment reports

**Excel Generation** (`reports/utils/excel_generator.py`):
- `ExcelReportGenerator` - Research data exports with:
  - Customizable field selection
  - Data anonymization for research compliance
  - Advanced filtering (POG, APGAR, GM diagnosis, HINE score, gender)
  - Data quality metrics and summary statistics
  - Multi-sheet workbooks with assessment-specific worksheets

**Report Models** (`reports/models.py`):
- `ReportTemplate` - Configurable header/footer/logo templates
- `ReportConfig` - System-wide report configuration settings

## Delete Helpers Module

**Entity Deletion Utilities** (`ndas/custom_codes/delete_helpers.py`):
```python
from ndas.custom_codes.delete_helpers import (
    has_delete_permission,    # Check user permission for entity deletion
    validate_can_delete,      # Business rule validation (e.g., videos in assessments)
    get_entity_display_name,  # Human-readable name for entities
    get_redirect_url,         # Post-deletion redirect URL by entity type
    get_entity_warning_items, # Cascade deletion warnings
    get_entity_detail_items,  # Entity details for confirmation modal
)
```

**Deletion Business Rules:**
- Superusers can delete any entity
- Staff can delete their own records (based on `added_by`)
- Videos cannot be deleted if referenced in assessments
- Patients show cascade warnings for related videos/assessments/attachments

## Quick Reference

```python
# Base imports
from ndas.custom_codes.Custom_abstract_class import TimeStampedModel, UserTrackingMixin
from ndas.custom_codes.custom_methods import getCountZeroIfNone, calculate_age_string, extract_video_metadata
from ndas.custom_codes.choice import MY_CHOICES
from ndas.custom_codes.validators import validate_video_file
from ndas.custom_codes.ndas_enums import PtStatus
from ndas.custom_codes.delete_helpers import has_delete_permission, validate_can_delete

# Middleware auto-tracking (no manual intervention needed)
# added_by - Set on creation
# last_edit_by - Updated on save

# Age calculation utility
from ndas.custom_codes.custom_methods import calculate_age_string
age_str = calculate_age_string(birth_date, current_date, format_type="medical")
# Returns: "2 weeks and 3 days", "1 year and 2 months", etc.

# Video metadata extraction
from ndas.custom_codes.custom_methods import extract_video_metadata
metadata = extract_video_metadata(video_path)
# Returns: {'duration_seconds': 120, 'resolution': '1920x1080', ...}
```
